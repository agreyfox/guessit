import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:guessit/utils/store.dart';
import 'package:guessit/webview.dart';
import 'Common.dart';


class HelpPage extends StatefulWidget {
  @override
  HelpState createState() => new HelpState();
}

class HelpState extends State<HelpPage> with SingleTickerProviderStateMixin {

  @override
  void initState() {
    super.initState();
    //print("Help-init");
  }

  @override
  void dispose() {
    super.dispose();
    //print("Help-dispose");
  }

  @override
  Widget build(BuildContext context) {
 
    return new Scaffold(
     /* appBar: new AppBar(
        title: new Text("规则说明"),
        centerTitle: true,
      ),*/
      body: new ListView(
          shrinkWrap: true,
          padding: new EdgeInsets.all(8.0),

          children: <Widget>[
            /*GestureDetector(
                onTap: () {
                  setState(() {
                    String url = "http://www.moacchina.net/forum.php?mod=forumdisplay&fid=113";
                    _launched = _launchInBrowser(url);
                  });

                },
                child: new Text('www.bing.com',style: new TextStyle(color: Colors.blue)),
              ),*/
            Text("Guessit预测游戏是预测上证指数的每天收盘点位的游戏，系统采用墨客区块链，公开透明竞猜数据，参与者应了解以下规则："),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("参与竞猜\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、游戏设置奖金池，游戏运营方每天注入ｘ个墨客（暂定），也欢迎参与者踊跃注入，注入地址为ｘｘｘｘ\n"),
            Text("2、每天竞猜数据精确到小数点后二位，比如预测大盘涨10.52个点，或者跌9.20个点，用户通过ａｐｐ界面输入点位．\n"),
            Text("3、每日竞猜时间为下午15:01到第二天的早上9:15分，超过时间系统会禁止。\n"),
            Text("4、每个参与者每天可以多次竞猜，但是以最后一次竞猜数据为准。注意每次竞猜提交都要消耗汽油费。"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("当日奖励\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每天如有几位参与者完全猜中当天的收盘价格（精确到小数点后面２位)，则平分奖金池中的所有奖金\n"),
            Text("2、每天竞猜最接近收盘价格的人获得奖金池里30%的奖金。 如有多人精确度相同，则多人平分奖金池里30%的奖金。精确度按照竞猜点位与收盘点位的差距计算， 同时考虑涨跌（大盘收盘平盘则按上涨计算）。\n"),
            Text("3、每天剩余奖金池转到下一交易日中。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("竞猜积分\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每日参与竞猜者，获得基础积分50分\n"),
            Text("2、每日竞猜前50名，获得额外积分等于51-积分排行。如第一名获得49分，第50名获得1分，并列的按照同样的积分计算，如两位参与者都获得第三名，则同时获得48分。\n"),
            Text("3、系统合约保留积分排名前1000位参与者的地址和积分。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("双周奖励\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每两周，按照积分最高的前三位（如积分相同，则同时计入），平分奖金池30%奖金。\n"),
            Text("2、奖励结束后，积分清零。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("特别说明\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、本竞猜游戏使用墨客结算，在每日提交预测时需要花费汽油费，系统为每个参与者开启了专用钱包地址（请务必妥善保存私钥），并注入了0.01墨客方便大家使用，若竞猜过度，请自行向钱包中打入墨客。\n"),

            new RichText(
              text: new TextSpan(
                text: "2、如要存取钱包地址中的墨客，可以安装TP钱包，并且按照TP钱包教程，做钱包备份、转账等等操作。TP钱包下载地址：",
                style: DefaultTextStyle.of(context).style,
                children: <TextSpan>[
                  new TextSpan(
                    text: "https://www.mytokenpocket.vip/, \n", style: new TextStyle(color: Colors.blue),
                    recognizer: new TapGestureRecognizer()
                      ..onTap = () {
                        String url = "https://www.mytokenpocket.vip/";
                        launchInBrowser(url);
                      },
                  ),
                  new TextSpan(text: "3、专用钱包地址保存在APP中，如卸载APP并且重新安装，则重新生成钱包地址，清除过往积分，重新开始游戏。\n"),
                  new TextSpan(text: "4、市道低迷，本游戏的目的就是提供一点小小的乐子。同时带有社区互动的实验性质，因此其中的规则设定，可能需要随着竞猜结果而做一定的调整，如奖励条件等。开发团队的原则是希望尽量做到公开公平。如有建议，则请到"),
                  new TextSpan(
                    text: "这里讨论 \n", style: new TextStyle(color: Colors.blue),
                    recognizer: new TapGestureRecognizer()
                      ..onTap = () {
                        String url = "http://www.moacchina.net/forum.php?mod=forumdisplay&fid=113";
                        launchInBrowser(url);
                      },
                  ),
                ],
              ),
            ),
          ]
      ),
    );
  
  }
 
}
/*   return new Scaffold(
     /* appBar: new AppBar(
        title: new Text("规则说明"),
        centerTitle: true,
      ),*/
      body: new ListView(
          shrinkWrap: true,
          padding: new EdgeInsets.all(8.0),

          children: <Widget>[
            /*GestureDetector(
                onTap: () {
                  setState(() {
                    String url = "http://www.moacchina.net/forum.php?mod=forumdisplay&fid=113";
                    _launched = _launchInBrowser(url);
                  });

                },
                child: new Text('www.bing.com',style: new TextStyle(color: Colors.blue)),
              ),*/
            Text("Guessit预测游戏是预测上证指数的每天收盘点位的游戏，系统采用墨客区块链，公开透明竞猜数据，参与者应了解以下规则："),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("参与竞猜\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、游戏设置奖金池，游戏运营方每天注入ｘ个墨客（暂定），也欢迎参与者踊跃注入，注入地址为ｘｘｘｘ\n"),
            Text("2、每天竞猜数据精确到小数点后二位，比如预测大盘涨10.52个点，或者跌9.20个点，用户通过ａｐｐ界面输入点位．\n"),
            Text("3、每日竞猜时间为下午15:01到第二天的早上9:15分，超过时间系统会禁止。\n"),
            Text("4、每个参与者每天可以多次竞猜，但是以最后一次竞猜数据为准。注意每次竞猜提交都要消耗汽油费。"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("当日奖励\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每天如有几位参与者完全猜中当天的收盘价格（精确到小数点后面２位)，则平分奖金池中的所有奖金\n"),
            Text("2、每天竞猜最接近收盘价格的人获得奖金池里30%的奖金。 如有多人精确度相同，则多人平分奖金池里30%的奖金。精确度按照竞猜点位与收盘点位的差距计算， 同时考虑涨跌（大盘收盘平盘则按上涨计算）。\n"),
            Text("3、每天剩余奖金池转到下一交易日中。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("竞猜积分\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每日参与竞猜者，获得基础积分50分\n"),
            Text("2、每日竞猜前50名，获得额外积分等于51-积分排行。如第一名获得49分，第50名获得1分，并列的按照同样的积分计算，如两位参与者都获得第三名，则同时获得48分。\n"),
            Text("3、系统合约保留积分排名前1000位参与者的地址和积分。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("双周奖励\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、每两周，按照积分最高的前三位（如积分相同，则同时计入），平分奖金池30%奖金。\n"),
            Text("2、奖励结束后，积分清零。\n"),
            new Container(
              margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
              decoration: new BoxDecoration(color: Colors.grey[300]),
              height: 5.0,
            ),
            Text("特别说明\n", textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold),),
            Text("1、本竞猜游戏使用墨客结算，在每日提交预测时需要花费汽油费，系统为每个参与者开启了专用钱包地址（请务必妥善保存私钥），并注入了0.01墨客方便大家使用，若竞猜过度，请自行向钱包中打入墨客。\n"),

            new RichText(
              text: new TextSpan(
                text: "2、如要存取钱包地址中的墨客，可以安装TP钱包，并且按照TP钱包教程，做钱包备份、转账等等操作。TP钱包下载地址：",
                style: DefaultTextStyle.of(context).style,
                children: <TextSpan>[
                  new TextSpan(
                    text: "https://www.mytokenpocket.vip/, \n", style: new TextStyle(color: Colors.blue),
                    recognizer: new TapGestureRecognizer()
                      ..onTap = () {
                        String url = "https://www.mytokenpocket.vip/";
                        launchInBrowser(url);
                      },
                  ),
                  new TextSpan(text: "3、专用钱包地址保存在APP中，如卸载APP并且重新安装，则重新生成钱包地址，清除过往积分，重新开始游戏。\n"),
                  new TextSpan(text: "4、市道低迷，本游戏的目的就是提供一点小小的乐子。同时带有社区互动的实验性质，因此其中的规则设定，可能需要随着竞猜结果而做一定的调整，如奖励条件等。开发团队的原则是希望尽量做到公开公平。如有建议，则请到"),
                  new TextSpan(
                    text: "这里讨论 \n", style: new TextStyle(color: Colors.blue),
                    recognizer: new TapGestureRecognizer()
                      ..onTap = () {
                        String url = "http://www.moacchina.net/forum.php?mod=forumdisplay&fid=113";
                        launchInBrowser(url);
                      },
                  ),
                ],
              ),
            ),
          ]
      ),
    );
  }*/
/*
class HelpState extends State<HelpPage> {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new Scaffold(
        appBar: new AppBar(
          title: new Text("规则说明"),
          centerTitle: true,
        ),
        body: new CustomScrollView(
              slivers: <Widget>[
                const SliverAppBar(
                  pinned: true,
                  expandedHeight: 250.0,
                  flexibleSpace: const FlexibleSpaceBar(
                    title: const Text('Demo'),
                  ),
                ),
                new SliverGrid(
                  gridDelegate: new SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200.0,
                    mainAxisSpacing: 10.0,
                    crossAxisSpacing: 10.0,
                    childAspectRatio: 4.0,
                  ),
                  delegate: new SliverChildBuilderDelegate(
                        (BuildContext context, int index) {
                      return new Container(
                        alignment: Alignment.center,
                        color: Colors.teal[100 * (index % 9)],
                        child: new Text('grid item $index'),
                      );
                    },
                    childCount: 20,
                  ),
                ),
                new SliverFixedExtentList(
                  itemExtent: 50.0,
                  delegate: new SliverChildBuilderDelegate(
                        (BuildContext context, int index) {
                      return new Container(
                        alignment: Alignment.center,
                        color: Colors.lightBlue[100 * (index % 9)],
                        child: new Text('list item $index'),
                      );
                    },
                  ),
                ),
              ],
            )

        ),
      );

  }
}
*/


/*
class HelpState extends State<HelpPage> {
  TextEditingController _myController = new TextEditingController(text: '1234');

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home:
      /*new Scaffold(
        appBar: new AppBar(
          title: new Text("规则说明"),
          centerTitle: true,
        ),
        body:*/ new Column(

          //shrinkWrap: true,
          //crossAxisAlignment: CrossAxisAlignment.start,
          //mainAxisSize: MainAxisSize.max,
          children: <Widget>[
                new AppBar(
                  title: Text('aaaaaaa'),
                  centerTitle: true,
                ),
                new Text("111sadf",style: new TextStyle(fontSize: 12.0)),
                new Text("2222sadf",style: new TextStyle(fontSize: 12.0)),
                new Text("2222sadf",style: new TextStyle(fontSize: 12.0)),
                new Text("2222sadf",style: new TextStyle(fontSize: 12.0)),
                new Text("2222sadf",style: new TextStyle(fontSize: 12.0)),
                new Text("333",style: new TextStyle(fontSize: 12.0)),

                     new TextField(
                       controller: _myController,

                       //decoration: null,
                     ),
                new Text("444sadf",style: new TextStyle(fontSize: 12.0)),
          ]
        ),
      );
  }
}
*/

