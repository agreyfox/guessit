import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:guessit/HomePage.dart';
import 'package:guessit/utils/guess-moac.dart';
import 'package:guessit/utils/store.dart';
import 'package:connectivity/connectivity.dart';

class Loader extends StatefulWidget {
  @override
  _LoaderState createState() => _LoaderState();
}

class _LoaderState extends State<Loader> with SingleTickerProviderStateMixin {
  AnimationController a_controller;
  Animation<double> a_rotation;
  Animation<double> a_radius_in;
  Animation<double> a_radius_out;
  final double initialradius = 30.0;
  final Connectivity _connectivity = Connectivity();
  double radius = 0.0;
  String msg;

  Config configInstance;
  bool ready;
  bool start;

  @override
  dispose() {
    if(a_controller.isAnimating){
      a_controller.dispose();

    }
    super.dispose();

    // _timer.cancel();
  }

  @override
  initState() {
    super.initState();
    start = false;
    a_controller =
        new AnimationController(vsync: this, duration: Duration(seconds: 5));

    a_rotation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
        parent: a_controller, curve: Interval(0.0, 1.0, curve: Curves.linear)));

    a_radius_in = Tween<double>(begin: 1.0, end: 0.0).animate(
        new CurvedAnimation(
            parent: a_controller,
            curve: Interval(0.75, 1.0, curve: Curves.elasticIn)));
    a_radius_out = Tween<double>(begin: 0.0, end: 1.0).animate(
        new CurvedAnimation(
            parent: a_controller,
            curve: Interval(0.0, 0.25, curve: Curves.elasticOut)));

    a_controller.addListener(() {
      setState(() {
        if (a_controller.value >= 0.75 && a_controller.value <= 1.0) {
          radius = a_radius_in.value * initialradius;
        } else if (a_controller.value >= 0.0 && a_controller.value <= 0.25) {
          radius = a_radius_out.value * initialradius;
        }
      });
    });
    //a_controller.repeat();
    a_controller.repeat();
    print("initialized finished");
    // DoInitial();
  }

  @override
  build(BuildContext cxt) {
    if (!start) {
      start = true;
      DoInitial(cxt);
    }
    return Container(
        color: Colors.teal,
        width: 100.0,
        height: 100.0,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RotationTransition(
                turns: a_rotation,
                child: Stack(
                  children: <Widget>[
                    Dot(
                      radius: 30.0,
                      color: Colors.black12,
                    ),
                    Transform.translate(
                      offset:
                          Offset(radius * cos(pi / 4), radius * sin(pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.lime,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(2 * pi / 4), radius * sin(2 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.redAccent,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(3 * pi / 4), radius * sin(3 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.yellowAccent,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(4 * pi / 4), radius * sin(4 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.indigo,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(5 * pi / 4), radius * sin(5 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.purpleAccent,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(6 * pi / 4), radius * sin(6 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(7 * pi / 4), radius * sin(7 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.blueAccent,
                      ),
                    ),
                    Transform.translate(
                      offset: Offset(
                          radius * cos(8 * pi / 4), radius * sin(8 * pi / 4)),
                      child: Dot(
                        radius: 5.0,
                        color: Colors.lightGreenAccent,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 45.0),
                child: new Text(msg == null ? "" : msg,
                    style: new TextStyle(
                        color: Colors.black,
                        fontSize: 24.0,
                        fontStyle: FontStyle.italic)),
              )
            ],
          ),
        ));
  }

  void DoInitial(BuildContext context) async {
    print("start to initilized env");
    configInstance = Config.getInstance;
    ready = false;
    try {
      //step 0 check network connectivity
      var connectivityResult = await (new Connectivity().checkConnectivity());
      if (connectivityResult == ConnectivityResult.none) {
        // I am connected to a mobile network.
        msg = "没有网络连接！";
        return;
      }
      // step 1 check system configure file ,
      var result = await configInstance.readJSONConfig();
      if (result == -1 || result == -2) {
        // if it is first time to reach, we need initial moac address
        msg = "初始化墨客账户信息";
        // 若没有配置文件，说明第一次来，初始化配置文件
        var ret = await configInstance.initMoacAddress();
        if (ret) {
          msg = "初始化成功，保存设置．．．";

          configInstance.writeJSONConfig();
          // cc.initalMoac();
        }
      }
      //step 2 获取新浪大盘指数
      bool ok = await configInstance.getSinaStockPrice("sh000001");

      if (ok) {
        setState(() {
          msg = "获取指数信息成功";
        });
      } else {
        msg = "获取大盘指数失败，请检查网络";
        return;
      }

      //step3 获取墨客network id and 账户balance;
      Guessit engine = new Guessit(Config.Host, Config.Port);
      configInstance.engine = engine;  //set the system wide moac engine

     // print("Moac server connnected " + await engine.getNetworkId().toString());
      //showMessage("网络连接成功，查询账户余额．．．");
      double amount = await engine.getBalance(configInstance.Address);
      configInstance.amount = amount;
      //print(amount);
    } catch (e) {
      print(e);
      msg = e.toString();
      return;
    }
    ready = true;
    Future.delayed(new Duration(seconds: 3), () {
  a_controller.dispose();
        Navigator.pushReplacement(
          context,
          new MaterialPageRoute(
              builder: (BuildContext context) => new HomePage()));
    });
  }
} // end of class

class Dot extends StatelessWidget {
  final double radius;
  final Color color;

  Dot({this.radius, this.color});
  @override
  Widget build(BuildContext cxt) {
    return Center(
      child: new Container(
        width: this.radius,
        height: this.radius,
        decoration: BoxDecoration(color: this.color, shape: BoxShape.circle),
      ),
    );
  }
}
