import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'Common.dart';

class MeRecord {
  String date;
  String shstock;
  String myguess;
  String rank;
  String reward;
}
class MePage extends StatefulWidget {
  @override
  MeState createState() => new MeState();
}

class MeState extends State<MePage> with SingleTickerProviderStateMixin {

  @override
  void initState() {
    super.initState();
    //print("Me-init");
  }

  @override
  void dispose() {
    super.dispose();
    //print("Me-dispose");
  }

  _getMyListData() {
    List<Widget> widgets = [];

    widgets.add(
      new Row(
          children: <Widget>[
            new Container(
              width: 52.0, height: 52.0,
              //margin: const EdgeInsets.only(left: 16.0),
              child: new Icon(Icons.person),
            ),
            new Container(
              child: new Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    new Container(
                      child: new Text(
                        "别名：野驴阿保机", style: TextStyle(fontSize: 10.0),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    new Container (
                      child: Text("钱包：$myPublicKey", style: TextStyle(fontSize: 10.0)),
                    ),
                  ]
              ),
            ),
          ]
      ),
    );
    widgets.add(
      new Container (
        margin: const EdgeInsets.only(left: 50.0),
        width: 50.0, height: 30.0,
        child: new Row(
            children: <Widget>[
              new RaisedButton(
                  color: Colors.blue[400],
                  child: new Text(
                      '复制公钥', style: new TextStyle(fontSize: 12.0, color: Colors.white)
                  ),
                  onPressed: (){
                    Clipboard.setData(new ClipboardData(text: (myPublicKey)));
                    //new MyAlertDialogView();
                    myDialog(context, '公钥已复制到剪辑板');
                  }
              ),
              new Container(
                margin: const EdgeInsets.only(left: 10.0),
                child: new Text(''),
              ),
              new RaisedButton(
                color: Colors.green[400],
                child: new Text(
                    '复制私钥', style: new TextStyle(fontSize: 12.0, color: Colors.white)
                ),
                onPressed: (){
                  Clipboard.setData(new ClipboardData(text: (myPrivateKey)));
                  myDialog(context, '私钥已复制到剪辑板');
                },
              )
            ]
        ),
      ),
    );
    widgets.add(
      new Container(
        margin: const EdgeInsets.only(top: 5.0, bottom: 5.0),
        decoration: new BoxDecoration(color: Colors.grey[200]),
        height: 5.0,
      ),
    );
    widgets.add(
      new Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Container(
                    child: Text("16", style: TextStyle(fontSize: 12.0))
                ),
                new Container(
                    child: Text("竞猜次数", style: TextStyle(fontSize: 12.0))
                )
              ],
            ),
            new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Container(
                    child: Text("15", style: TextStyle(fontSize: 12.0))
                ),
                new Container(
                    child: Text("中奖次数", style: TextStyle(fontSize: 12.0))
                )
              ],
            ),
            new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Container(
                    child: Text("14", style: TextStyle(fontSize: 12.0))
                ),
                new Container(
                    child: Text("中奖金额", style: TextStyle(fontSize: 12.0))
                )
              ],
            ),
            new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Container(
                    child: Text("13", style: TextStyle(fontSize: 12.0))
                ),
                new Container(
                    child: Text("本期积分", style: TextStyle(fontSize: 12.0))
                )
              ],
            )
          ]
      ),
    );
    widgets.add(
      new Container(
        margin: const EdgeInsets.only(top: 5.0),
        decoration: new BoxDecoration(color: Colors.grey[200]),
        height: 5.0,
      ),
    );
    widgets.add(
      new Container(
        //margin: const EdgeInsets.all(5.0),
        margin: const EdgeInsets.only(top: 5.0),
        //padding: const EdgeInsets.all(5.0),
        //decoration: new BoxDecoration(
        //  color: Colors.grey.shade200,
        //),
        child: Text("竞猜记录",
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold, color: Colors.black,),
        ),
      ),
    );
    widgets.add(new Divider());

    widgets.add(
      new Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          new Container(
            child: Text("  日  期  "),
          ),
          new Container(
            child: Text("上证指数"),
          ),
          new Container(
            child: Text("我的点位"),
          ),
          new Container(
            child: Text("  排名  "),
          ),
          new Container(
            child: Text("  奖励  "),
          ),
        ],
      ),
    );
    // 这是我的成绩记录
    List<MeRecord> myrecord = [];
    MeRecord my = new MeRecord();
    my.date = '2018-09-03';
    my.shstock = '  2700.12  ';
    my.myguess = '  2700.53  ';
    my.rank = '     1     ';
    my.reward = '     0     ';
    myrecord.add(my);

    for (int i = 1; i < 10; i++) {
      widgets.add(
          new Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new Container(
                  child: Text(my.date),
                ),
                new Container(
                  child: Text(my.shstock),
                ),
                new Container(
                  child: Text(my.myguess),
                ),
                new Container(
                  child: Text(my.rank),
                ),
                new Container(
                  child: Text(my.reward),
                ),
              ]
          )
      );
    }
    /*
        for (int i = 1; i < 20; i++) {
          widgets.add(new Padding(
              padding: new EdgeInsets.all(10.0),
              child: new Text("Row $i")));
        }*/
    return widgets;
  }
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
       /* appBar: new AppBar(
          title: new Text("我"),
          centerTitle: true,
        ),*/
        body: new ListView.builder(
            itemCount: _getMyListData().length,
            itemBuilder: (BuildContext context, int position)
            {
              return _getMyListData()[position];
            }
        )

    );
  }
}
