class Compain {
  final String title;
  final String day;
  final String classname;
  final String contract;
  const Compain({this.title,this.day,this.classname,this.contract});
}