class Result {
  final String name;
  final String tx;
  final String addr;
  final String point;
  final bool binggo;

  Result(this.name, this.tx, this.addr, this.point, this.binggo);
 }