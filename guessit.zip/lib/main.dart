import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/src/scheduler/ticker.dart';
import 'package:guessit/Loader.dart';
import 'package:guessit/utils/store.dart';
import 'Guess.dart';
import 'DataPage.dart';
import 'HelpPage.dart';
import 'MePage.dart';
import "dart:math";

void main() {
  runApp(new DoubanApp());
}

class DoubanApp extends StatefulWidget {
  @override
  DoubanAppState createState() => new DoubanAppState();
}

class DoubanAppState extends State<DoubanApp>{
   // with SingleTickerProviderStateMixin {
//  TabController controller;
  //List<Widget> list = List();

  @override
  void initState() {
    ///list..add(GuessPage())..add(DataPage())..add(HelpPage())..add(MePage());

    //  controller = new TabController(length: 4, vsync: this);

    super.initState();
    print("Main-init");
  }

  @override
  void dispose() {
    //  controller.dispose();
    super.dispose();
    print("Main-dispose");
  }

  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      theme: new ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: new Loader(),
    );
  }
}

//*****************************************************************

