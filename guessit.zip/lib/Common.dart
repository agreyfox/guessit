import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';

String myPublicKey = '0xb037ff99dc90ebe31e456998751a942fe21ad0ac';
String myPrivateKey = '0xb037ff99dc90ebe31e456998751a942fe21ad0ac';

Future<Null> launchInBrowser(String url) async {
  if (await canLaunch(url)) {
    await launch(url, forceSafariVC: false, forceWebView: false);
  } else {
    throw '404: $url';
  }
}


Future<Null> launchInWebViewOrVC(String url) async {
  if (await canLaunch(url)) {
    await launch(url, forceSafariVC: true, forceWebView: true);
  } else {
    throw '404: $url';
  }
}

Future<bool> myCopy(BuildContext context, String msg, bool tx) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return new AlertDialog(
          title: new Text(msg, style: new TextStyle(fontSize: 12.0)),
          actions: <Widget>[
            new FlatButton(
              child: new Text('复制到剪辑版'),
              onPressed: () {
                Clipboard.setData(new ClipboardData(text: msg));
                Navigator.of(context).pop(true);
                myDialog(context, '已复制到剪辑板');
              },
            ),

            new FlatButton(
              child: new Text('区块浏览器'),
              onPressed: () {
                Navigator.of(context).pop(false);
                String _url;
                if (tx)
                  _url = "http://explorer.moac.io/tx/"+msg;
                else
                  _url = "http://explorer.moac.io/addr/"+msg;
                launchInBrowser(_url);
              },
            )
          ],
        );
      });
}

Future<bool> myDialog(BuildContext context, String msg) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return new AlertDialog(
          title: new Text(msg),
          actions: <Widget>[
            new FlatButton(
              child: new Text('确定'),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
            ),
            /*
            new FlatButton(
              child: new Text('No'),
              onPressed: () {
                Navigator.of(context).pop(false);
              },
            ) */
          ],
        );
      });
}

Future<bool> myYesNoDialog(BuildContext context, String msg) {
  return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return new AlertDialog(
          title: new Text(msg),
          actions: <Widget>[
            new FlatButton(
              child: new Text('确定'),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
            ),

            new FlatButton(
              child: new Text('否'),
              onPressed: () {
                Navigator.of(context).pop(false);
              },
            )
          ],
        );
      });
}

/*
class MyAlertDialogView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new RaisedButton(
      child: new Text('显示AlertDialog'),
      onPressed: () {
        showDialog<Null>(
          context: context,
          barrierDismissible: false, // 不能点击对话框外关闭对话框，必须点击按钮关闭
          builder: (BuildContext context) {
            return new AlertDialog(
              title: new Text('提示'),
              content: new Text('微软重申Windows 7将在2020年1月到达支持终点，公司希望利用这个机会说服用户在最新更新发布之前升级到Windows 10。'),
              actions: <Widget>[
                new FlatButton(
                  child: new Text('明白了'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
      },
    );
  }
}

class MySimpleDialogView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new RaisedButton(
      child: new Text('显示SimpleDialog'),
      onPressed: () {
        showDialog(
            context: context,
            builder: (BuildContext ctx) {
              return new SimpleDialog(
                title: new Text('这是SimpleDialog'),
                children: <Widget>[
                  new SimpleDialogOption(
                    onPressed: () { Navigator.pop(context); },
                    child: const Text('确定'),
                  ),
                  new SimpleDialogOption(
                    onPressed: () { Navigator.pop(context); },
                    child: const Text('取消'),
                  ),
                ],
              );
            }
        );
      },
    );
  }
}
*/
