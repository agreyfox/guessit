import 'package:flutter/material.dart';
import 'Common.dart';

class MeRecord {
  String date;
  String guess;
  String tx;
}
class MySubmitResultPage extends StatefulWidget {
  @override
  MySubmitResultState createState() => new MySubmitResultState();
}

class MySubmitResultState extends State<MySubmitResultPage> {
  List <Color> _selectedColor = [];
  int _nItems = 10;

  _getListData(BuildContext context) {

    List<Widget> widgets = [];

    // 这是我的成绩记录
    List<MeRecord> myrecord = [];
    MeRecord my = new MeRecord();
    my.date = '2018-09-03 12:12:12';
    my.guess = "2727.27";
    my.tx = '0xd3efcbe6cd3fb36158cf2759c973dcbb0c39933d11a563cc85a30deefe46eaa9';
    myrecord.add(my);

    for (int i=0; i<_nItems; i++) _selectedColor.add(Colors.black);
    for (int i = 0; i < _nItems; i++) {
      if (i>0) widgets.add(new Divider(color: Colors.black,));
      widgets.add(
          new Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new Expanded(
                  child: new IconButton(
                    icon: new Icon(Icons.search, color: Colors.blue),
                    tooltip: '打开区块浏览器查看',
                    onPressed: () { setState(() {  });},
                  ),
                  flex: 1,
                ),
                new Expanded(
                  child: new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        new Text('时间：'+my.date,
                            style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                        new Text('竞猜：'+my.guess,
                            style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                        new Row(
                            children: <Widget>[
                              new Text('交易：', style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                              new Expanded(
                                  child: new GestureDetector(
                                    onTap: (){
                                      for(int j=0; j<_nItems; j++) _selectedColor[j] = Colors.black;
                                      _selectedColor[i] = Colors.red;
                                      setState(() {
                                      });
                                    },
                                    onLongPress: (){
                                      for(int j=0; j<_nItems; j++) _selectedColor[j] = Colors.black;
                                      _selectedColor[i] = Colors.red;
                                      setState(() {
                                        myCopy(context,my.tx, true);
                                      });
                                    },
                                    child: new Text(my.tx, style: new TextStyle(fontSize: 12.0, color: _selectedColor[i],fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                                  )),
                            ]
                        )
                      ]
                  ),
                  flex: 5,
                ),
              ]
          )
      );
    }
    return widgets;
  }
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text("已提交记录"),
          centerTitle: true,
        ),
        body: new ListView.builder(
            padding: new EdgeInsets.all(8.0),

            itemCount: _getListData(context).length,
            itemBuilder: (BuildContext context, int position)
            {
              return _getListData(context)[position];
            }
        )
    );
  }
}


/*

                new Expanded(
                  child: new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                          new Text('时间：'+my.date,
                                      style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                          new Text('竞猜：'+my.guess,
                                      style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                          new Text('TX:'+my.tx,
                                      style: new TextStyle(fontSize: 12.0, color: Colors.black,fontWeight: FontWeight.normal, decoration: TextDecoration.none))
                      ]
                  ),
                  flex: 5,
                ),


 */