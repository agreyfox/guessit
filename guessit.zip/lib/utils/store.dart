import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'dart:math';
import 'package:guessit/utils/guess-moac.dart';
import 'package:moac/moac.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:moac/moac_server_client.dart';
import 'package:gbk2utf8/gbk2utf8.dart';
import 'package:tripledes/tripledes.dart';

class Config {
  static final Config _config = new Config._internal();
  static const String Host = "118.193.95.58";
  static const String MoacPort = ":8545";
  static const Port = 8545;
  static const String ServicePort = ":11545";
  static const String URL =
      "http://" + Host + ServicePort + "/pages/instruction.html";
  static const String getOpenBid = "/ava";
  static const String getWallet = "/cru";
  static const String getVersion = "/ver";
  static const String getUserStat = "/stat";
  

  bool firstrun;
  String PrivateKey;
  String PublicKey;
  String Address;
  String nickname = "";
  double amount ;

  static const VERSION = 0.1;
  List<String> stockdata;
  dynamic _cache ;   //get Version 's data 
  //String dpIndex;
  String _dpstr;
  dynamic _submit;
  static const _basekey = "0x75041efc0fb09911cb33224e8c0b3f63575e89be";

  factory Config() {
    return _config;
  }

  
  //MoacServerClient client;
  Guessit engine;
  var dir;
  bool ready = false;
  static final CONFIGFILE = "szccc.json";
  static final HISTORYFILE = "his.dat";
  Map<String, String> _jsonconfig;

  Future<String> get localPath async {
    dir = await getApplicationDocumentsDirectory();
    return dir.path;
  }

  static get getInstance => _config;
  String get DPstr => _dpstr;
  double get version => VERSION;
  Future<bool> get dpIndex => getSinaStockPrice("sh000001");
  bool get isSubmit => _submit["hash"] != Null;

  
  Future<File> get configFile async {
    final path = await localPath;
    return File("$path/" + CONFIGFILE);
  }

  Future<int> readConfig() async {
    try {
      final file = await configFile;
      // Read the file
      String contents = await file.readAsString();
      // print(contents);
      return int.parse(contents);
    } catch (e) {
      // If we encounter an error, return 0
      return 0;
    }
  }

  Config._internal();

  void list(String path) {
    try {
      Directory root = new Directory(path);
      if (root.existsSync()) {
        for (FileSystemEntity f in root.listSync()) {
          print(f.path);
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  bool writeFile(String file, String data, FileMode mode) {
    try {
      File f = new File(file);
      RandomAccessFile rf = f.openSync(mode: mode);
      rf.writeStringSync(data);
      rf.flushSync();
      rf.closeSync();
      return true;
    } catch (e) {
      print(e.toString());
      return false;
    }
  }

  String readFile(String file) {
    try {
      File f = new File(file);
      return f.readAsStringSync();
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  List<String> readLines(String file) {
    try {
      File f = new File(file);
      return f.readAsLinesSync();
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future<bool> writeJSONConfig() async {
    var file = await localPath + "/" + CONFIGFILE;
    print("save the config file");
    Map<String, String> map = new Map<String, String>();
    _jsonconfig = new Map<String, String>();
    _jsonconfig["Private"] = PrivateKey;
    _jsonconfig["Public"] = PublicKey;
    _jsonconfig["Address"] = Address;
    _jsonconfig["Email"] = "a@first.bird";
    _jsonconfig["Date"] = DateTime.now().toLocal().toString();
    String data = json.encode(_jsonconfig);
    print(data);
    return writeFile(file, data, FileMode.WRITE);
  }

  Future<int> readJSONConfig() async {
    String file = await localPath + "/" + CONFIGFILE;
    print(file);
    String data = readFile(file);
    if (data == null) {
      print("no such file");
      return -1;
    }
    if (data.isEmpty) {
      print("no data in config file");
      return -2;
    }
    _jsonconfig = new Map<String, String>();
    var abc = jsonDecode(data);
    PrivateKey = abc['Private'];
    PublicKey = abc['Public'];
    Address = '0x' + abc['Address'];
    print(Address);
    return 1;
  }

  //初始化墨客钱包
  Future<bool> initMoacAddress() async {
    print("initial moac account");
    try {
      var res = await http.get("http://" + Host + ServicePort + "/cru");
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        PrivateKey = data['private'];
        PublicKey = data['public'];
        Address = data['address'];
        return true;
      } else {
        print("server return error ${res.statusCode}");
        return false;
      }
    } catch (e) {
      print("error $e");
      return false;
    }
  }

//需要得到用户今日是否提交，提交的点位和ｈａｓｈ
//如果已经计算完成，同时返回预测准确度？ToDo
  Future<dynamic> getUserStatBid() async {
    print("get user state ");
    try {
      var blockCipher = new BlockCipher(new DESEngine(), _basekey);
      var content = blockCipher.encodeB64(Address);

      var res = await http.get(
        "http://" + Host + ServicePort + getUserStat,
        headers: {
          //  'Content-type': 'application/json; charset=utf-8',
          'me': content,
        },
      );
      if (res.statusCode == 200) {
        if (res.body == "") {
          return null;
        }
        var data = jsonDecode(res.body);
        return data;
      } else {
        print("server return error ${res.statusCode}");
        return null;
      }
    } catch (e) {
      print("Store Error $e");
      return null;
    }
  }

  Future<dynamic> getAvaliableBid() async {
    print("get open bid ");
    try {
      var res = await http.get("http://" + Host + ServicePort + getOpenBid);
      if (res.statusCode == 200) {
        if (res.body == "") {
          return null;
        }
        var data = jsonDecode(res.body);
        return data;
      } else {
        print("server return error ${res.statusCode}");
        return null;
      }
    } catch (e) {
      print("Store Error $e");
      return null;
    }
  }

  Future<dynamic> getVersionInfo() async {
    print("get version  ");
    try {
      var res = await http.get("http://" + Host + ServicePort + getVersion);
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        _cache = data;
        // print(data);
        //_submit = data["submit"]; // TODO, Return user 今天是否submit 需要吗？
        return data;
      } else {
        print("server return error ${res.statusCode}");
        return null;
      }
    } catch (e) {
      print("error $e");
      return false;
    }
  }

  Future<dynamic> submitBid(double point, String dayinfo) async {
    print("submit bid");
    try {
      var blockCipher = new BlockCipher(new DESEngine(), _basekey);

      // var ciphertext = blockCipher.encodeB64(message);
      //var decoded = blockCipher.decodeB64(ciphertext);

      var content =
          blockCipher.encodeB64([Address, PrivateKey].join(",").toString());
      //print([Address, PrivateKey].join(",").toString());
      int ms = DateTime.now().millisecondsSinceEpoch;
      var bb = new BlockCipher(new DESEngine(), Address);
      String keyyy = bb.encodeB64(ms.toString() + "," + Address);
      //print( ms.toString()+","+Address);
      //String dayinfo = "2018-9-26";
      Map data = {
        'point': point.toStringAsFixed(2),
        'name': dayinfo //上证0912 这种
      };
      // print(data);
      var res = await http.post("http://" + Host + ServicePort + "/play",
          headers: {
            //  'Content-type': 'application/json; charset=utf-8',
            'me': content,
            'key': keyyy
          },
          body: data);
      print(res.body);
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        _submit = data["msg"];
        return data;
      } else {
        print("server return error ${res.statusCode}");
        return null;
      }
    } catch (e) {
      print("error $e");
      return null;
    }
  }

  Future<bool> getSinaStockPrice(String abc) async {
    // biz.finance.新浪.康.西恩/stock/flash_hq/kline_data.php?symbol=sh600000&end_date=20121231&begin_date=20111231
    try {
      var res = await http.get("http://hq.sinajs.cn/list=" + abc);
      String str = decodeGbk(res.bodyBytes);

      stockdata = str.split(",");

      _dpstr = stockdata[2];

      return true;
    } catch (e) {
      print("Sina Server error $e");
      return false;
    }
  }

}
