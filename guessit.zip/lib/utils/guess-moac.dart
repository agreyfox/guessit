import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'dart:math';
import 'package:moac/moac.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:moac/moac_server_client.dart';
import 'package:gbk2utf8/gbk2utf8.dart';

class Guessit {
  final String guessitAddr = "0xf4c88270a93189ceb9d7ad78a9c69653ad82b41c";
  var prefix;
  String Addr;
  MoacServerClient _client;

  Guessit(String host, int port) {
    initalMoac(host, port);
  }
  
  Future<bool> initalMoac(String host, int port) async {
    print("initial moac client connection");
    prefix = pow(10, 18);
    try {
      _client = MoacServerClient.withConnectionParameters(host, port);
      var abc = _client.toString();
      if (abc != null) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      throw ("区块链连接失败");
    }
  }

  String normalizedAddr(String acct) {
    var addr;
    if (acct.startsWith("0x")) {
      addr = acct;
    } else {
      addr = '0x' + acct;
    }
    return addr;
  }



  Future<double> getBalance(String acct) async {
    double balance;
    try {
      final MoacDefaultBlock block = MoacDefaultBlock();
      block.pending = true;
      var addr;
      if (acct.startsWith("0x")) {
        addr = acct;
      } else {
        addr = '0x' + acct;
      }
      final int bb =
          await client.getBalance(MoacUtilities.safeParse(addr), block);
      balance = bb.toDouble() / prefix;
    } catch (e) {
      // print(e);
      balance = 0.0;
    } finally {
      return balance;
    }
  }
  
  MoacServerClient get client => _client;

  Future<int> getNetworkId () async{
     try {
      print(await client.netVersion());
     return client.id;
     
    } catch (e) {
      return null;
    } 
  }

}
