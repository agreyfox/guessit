import 'package:flutter/material.dart';

import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class WebViewPages extends StatelessWidget {
  final String url;

  WebViewPages(this.url);
  final flutterWebviewPlugin = new FlutterWebviewPlugin();

  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(
        appBar: new AppBar(
          title: new Text(""),
          centerTitle: true,
          titleSpacing: 20.9,
          leading: IconButton(
            icon: Icon(Icons.backspace),
            onPressed: () {Navigator.pop(context);},
          ),
        ),
        url: url,
        withZoom: true,
        //clearCache: true,
        withJavascript: true);
  }
}
