import 'package:flutter/material.dart';

class DialogHero extends StatelessWidget {
  String message;
  final double width;
  final VoidCallback onTap;

  DialogHero({Key key,this.message,this.onTap,this.width}):super(key:key);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: 500.0,
      child:new Hero(
        tag:"center",
        child:Material(
          child:new InkWell(
            child: Text(message)
          )
        )
      )
        
    );
  }
  void setMessage(String msg) {
    message = msg;
  }
}