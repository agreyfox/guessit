import 'package:flutter/material.dart';
import 'package:guessit/DataPage.dart';
import 'package:guessit/Guess.dart';
import 'package:guessit/HelpPage.dart';
import 'package:guessit/MePage.dart';
import 'package:guessit/utils/store.dart';
import 'package:guessit/webview.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => new _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  TabController tcontrol;
  @override
  void initState() {
    super.initState();
    tcontrol = new TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    // Clean up the controller when the Widget is disposed
    //_myGuessInputController.dispose();
    super.dispose();
    tcontrol.dispose();
    print("Guess-dispose");
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text("Guessit"),
        centerTitle: true,
      ),
      body: new TabBarView(controller: tcontrol, children: <Widget>[
        new GuessPage(),
        new DataPage(),
        new HelpPage(),
        new MePage(),
      ]),
      bottomNavigationBar: new Material(
          color: Colors.teal,
          child: new TabBar(
            controller: tcontrol,
            tabs: <Widget>[
              new Tab(icon: new Icon(Icons.favorite), text: "预测"),
              new Tab(icon: new Icon(Icons.data_usage), text: "数据"),
              new Tab(icon: new Icon(Icons.help), text: "预测"),
              new Tab(
                icon: new Icon(Icons.people),
                text: "我",
              )
            ],
          )),
    );
  }
    }