import 'package:flutter/material.dart';
import 'Common.dart';

class DataRecord {
  String date;
  String paticipates;
  String shstock;
  String average;
  String deviation;
}
class Score {
  String addr;
  String score;
}

class DataPage extends StatefulWidget {
  @override
  DataState createState() => new DataState();
}

class DataState extends State<DataPage> with SingleTickerProviderStateMixin {
  TabController _tabDataController;

  @override
  void initState() {
    _tabDataController = new TabController(vsync: this, length: 4);
    super.initState();
    //print("Data-init");
  }

  @override
  void dispose() {
    _tabDataController.dispose();
    super.dispose();
    //print("Data-dispose");
  }

  @override

  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        //title: new Text("数 据"),
        //centerTitle: true,
        title: new TabBar(
          //isScrollable: true,
          controller: _tabDataController,
          tabs: <Widget>[
            Tab(text: "当日数据",),
            //Tab(text: "昨日排行",),
            Tab(text: "本期排行",),
            Tab(text: "数据统计",),
          ],
          //indicatorColor: _indicatorColor,
        ),
      ),
      body: new TabBarView(
        controller: _tabDataController,
        children: <Widget>[
          //DataStatisticsPage(),
          DataDayPage(),
          DataRankPage(),
          DataStatisticsPage(),
        ],
      ),

    );
  }
}
//***************************************************************
//            当日数据
//***************************************************************
class DataDayPage extends StatefulWidget {
  @override
  DataDayPageState createState() => new DataDayPageState();
}

class DataDayPageState extends State<DataDayPage> {

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget dataHeaderWidget() {
    List<String> dataName = ['日 期：','参与人数：','奖金池：','上证收盘：','竞猜均值：','误差：'];
    List<num> dataValue = [2018, 123, 10, 2702.34,2703.12, 0.05 ];

    List<Widget> _dataHeadWidget = [];

    for (int i = 0; i < 6; i++) {
      _dataHeadWidget.add(
        new Row (
          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            new Expanded(
              child: new Container(
                //decoration: new BoxDecoration(color: Colors.blue),
                margin: const EdgeInsets.only(right: 20.0),
                alignment: Alignment.centerRight,
                child: new Text(dataName[i],
                    style: TextStyle(fontSize: 14.0, color: Colors.black54)),
              ),
              flex: 1,
            ),
            new Expanded(
              child: new Container(
                margin: const EdgeInsets.only(right: 30.0),
                alignment: Alignment.centerRight,
                child: new Text(dataValue[i].toString(),
                    style: TextStyle(fontSize: 14.0, color: Colors.black,)),
              ),
              flex: 1,
            ),
            new Expanded(
              child: new Container(
                margin: const EdgeInsets.only(right: 30.0),
                alignment: Alignment.centerRight,
                child: new Text(dataValue[i].toString(),
                    style: TextStyle(fontSize: 14.0, color: Colors.black,)),
              ),
              flex: 1,
            ),
          ],
        ),
      );
    };
    return Column(
      children: _dataHeadWidget,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
        children: <Widget> [
          new Text(''),
          dataHeaderWidget(),
        ]
    );
  }
}


//***************************************************************
//            数据排行榜
//***************************************************************
class DataRankPage extends StatefulWidget {
  @override
  DataRankPageState createState() => new DataRankPageState();
}

class DataRankPageState extends State<DataRankPage> {

  List <Color> _selectedColor = [];
  int _nItems = 10;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  _getListData() {

    List<Widget> widgets = [];

    // 这是我的成绩记录
    List<Score> score = [];
    final Score sco = new Score();
    sco.addr = myPublicKey;
    sco.score = '1234';
    score.add(sco);

    for (int i=0; i<_nItems; i++) _selectedColor.add(Colors.black);
    for (int i = 0; i < _nItems; i++) {
      //selectedColor = Colors.black;
      widgets.add(
          new Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new Expanded(child: Container(alignment: Alignment.center, child: Text(sco.score, style: TextStyle(fontSize: 12.0))), flex: 1),
                //new Expanded(child: Container(alignment: Alignment.center, child: Text(sco.addr, style: TextStyle(fontSize: 12.0))), flex: 6),
                new Expanded(
                  child: new GestureDetector(
                    onTap: (){
                      for(int j=0; j<_nItems; j++) _selectedColor[j] = Colors.black;
                      _selectedColor[i] = Colors.red;
                      setState(() {
                        //_selectedColor = Colors.red;
                      });
                    },
                    onLongPress: (){
                      for(int j=0; j<_nItems; j++) _selectedColor[j] = Colors.black;
                      _selectedColor[i] = Colors.red;
                      setState(() {
                        myCopy(context,sco.addr, false);
                      });
                    },
                    child: new Text(sco.addr, style: new TextStyle(fontSize: 12.0, color: _selectedColor[i],fontWeight: FontWeight.normal, decoration: TextDecoration.none)),
                  ),
                  flex: 6,
                ),
              ]
          )
      );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
        children: <Widget> [
          new Text(''),
          new Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Expanded(child: Container(alignment: Alignment.center, child: Text("积分")), flex: 1,),
              new Expanded(child: Container(alignment: Alignment.center, child: Text("钱包地址")),flex: 6),
            ],
          ),

          new Divider(),

          new Expanded(
            child: new ListView.builder(
                itemCount: _getListData().length,
                itemBuilder: (BuildContext context, int position) { return _getListData()[position]; }
            ),
          ),
        ]
    );
  }
}





//***************************************************************
//            数据统计
//***************************************************************
class DataStatisticsPage extends StatefulWidget {
  @override
  DataStatisticsPageState createState() => new DataStatisticsPageState();
}

class DataStatisticsPageState extends State<DataStatisticsPage> {

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  _getListData() {
    List<Widget> widgets = [];

    // 这是我的成绩记录
    List<DataRecord> datarecord = [];
    DataRecord rec = new DataRecord();
    rec.date = '2018-09-03';
    rec.paticipates = '1234';
    rec.shstock = '2700.12 ';
    rec.average = '2700.53';
    rec.deviation = '-11.23';
    datarecord.add(rec);

    for (int i = 1; i < 20; i++) {
      widgets.add(
          new Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                new Expanded(child: Container(alignment: Alignment.center, child: Text(rec.date)), flex: 4),
                new Expanded(child: Container(alignment: Alignment.center, child: Text(rec.paticipates)), flex: 3),
                new Expanded(child: Container(alignment: Alignment.center, child: Text(rec.shstock)), flex: 3),
                new Expanded(child: Container(alignment: Alignment.center, child: Text(rec.average)), flex: 3),
                new Expanded(child: Container(alignment: Alignment.center, child: Text(rec.deviation)), flex: 2),
              ]
          )
      );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
        children: <Widget> [
          new Text(''),
          new Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              new Expanded(child: Container(alignment: Alignment.center, child: Text("日  期")),flex: 4),
              new Expanded(child: Container(alignment: Alignment.center, child: Text("参与人数")), flex: 3,),
              new Expanded(child: Container(alignment: Alignment.center, child: Text("上证收盘")), flex: 3,),
              new Expanded(child: Container(alignment: Alignment.center, child: Text("竞猜均值")), flex: 3,),
              new Expanded(child: Container(alignment: Alignment.center, child: Text("误 差%")), flex: 2,),
            ],
          ),

          new Divider(),

          new Expanded(
            child: new ListView.builder(
                itemCount: _getListData().length,
                itemBuilder: (BuildContext context, int position) { return _getListData()[position]; }
            ),
          ),
        ]
    );
  }
}

