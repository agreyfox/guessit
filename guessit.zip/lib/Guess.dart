import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'Common.dart';
import 'SubmitResultPage.dart';
import 'utils/store.dart';

//import 'package:flutter/gestures.dart';

class GuessPage extends StatefulWidget {
  @override
  GuessState createState() => new GuessState();
}

class GuessState extends State<GuessPage> with SingleTickerProviderStateMixin {
  double percent() => 100 * (myGuess - lastSHClose) / lastSHClose;
  TextEditingController _myGuessInputController;
  BuildContext cxt;
  Config configInstance;
  String splashstr;
  bool ready;
  bool wait;
  double amount = 0.0;
  double lastSHClose;
  double myGuess;
  double step;

  @override
  void initState() {
   _myGuessInputController = new TextEditingController();
    //final myGuess = lastSHClose;
    ready = false;
    super.initState();
    //print("Guess-init");
    setupParameter();
     
   // _myGuessInputController.text = myGuess.toStringAsFixed(2);

  }

  @override
  void dispose() {
    // Clean up the controller when the Widget is disposed
    _myGuessInputController.dispose();
    super.dispose();
    //print("Guess-dispose");
  }

  //****** 按 ‘-’这按钮
  void _onPressedMinus() {
    if (myGuess == 0.0) return;
    setState(() {
      // 跌幅不能超过 10%
      if ((myGuess - step) > lastSHClose * 0.9) myGuess = myGuess - step;
      _myGuessInputController.text = myGuess.toStringAsFixed(2);
    });
  }

  void _onPressedPlus() {
    if (myGuess == 0.0) return;
    setState(() {
      // 涨幅不能超过 10%
      if ((myGuess + step) < lastSHClose * 1.1) myGuess = myGuess + step;
      _myGuessInputController.text = myGuess.toStringAsFixed(2);
    });
  }

  void _longPressMinus() {
    if (myGuess == 0.0) return;
    setState(() {
      // 跌幅不能超过 10%
      if ((myGuess - step * 100) > lastSHClose * 0.9)
        myGuess = myGuess - step * 100;
      _myGuessInputController.text = myGuess.toStringAsFixed(2);
    });
  }

  void _longPressPlus() {
    if (myGuess == 0.0) return;
    setState(() {
      // 涨幅不能超过 10%
      if ((myGuess + step * 100) < lastSHClose * 1.1)
        myGuess = myGuess + step * 100;
      _myGuessInputController.text = myGuess.toStringAsFixed(2);
    });
  }

  //**************************************************************************************************//

  @override
  Widget build(BuildContext context) {
    cxt = context; // save the context for next use;
    return new Scaffold(
      body: new ListView(children: <Widget>[
        /*new AppBar(
              title: Text('预 测'),
              centerTitle: true,
            ),*/
        new Row(children: <Widget>[
          new Container(
            width: 52.0, height: 52.0,
            //margin: const EdgeInsets.only(left: 16.0),
            child: new Icon(Icons.person),
          ),
          new Container(
            child: new Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  new Text(
                    configInstance.nickname != null
                        ? configInstance.nickname
                        : "",
                    style: TextStyle(
                        fontSize: 12.0,
                        color: Colors.black,
                        fontWeight: FontWeight.normal,
                        decoration: TextDecoration.none),
                  ),
                  new Text("钱包：" + configInstance.Address,
                      style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          decoration: TextDecoration.none)),
                  new Text("余额(moac): ${configInstance.amount}",
                      style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.black,
                          fontWeight: FontWeight.normal,
                          decoration: TextDecoration.none)),
                ]),
          ),
        ]),
        new Container(
          margin: const EdgeInsets.only(top: 5.0),
          decoration: new BoxDecoration(color: Colors.grey[200]),
          height: 5.0,
        ),
        new Container(
            alignment: Alignment.centerLeft,
            margin: const EdgeInsets.only(left: 5.0, top: 10.0, bottom: 10.0),
            child: new RichText(
              text: new TextSpan(
                text: '上证指数昨收：',
                style: DefaultTextStyle.of(context).style,
                children: <TextSpan>[
                  new TextSpan(
                      text: lastSHClose.toString(),
                      style: new TextStyle(color: Colors.red)),
                ],
              ),
            )),
        new Container(
            alignment: Alignment.centerLeft,
            margin: const EdgeInsets.only(left: 5.0, top: 20.0, bottom: 10.0),
            child: new RichText(
              text: new TextSpan(
                text: '我的预测涨跌： ',
                style: DefaultTextStyle.of(context).style,
                children: <TextSpan>[
                  new TextSpan(
                      text: "%",
                      style: new TextStyle(color: Colors.red)),
                ],
              ),
            )),
        new Container(
          alignment: Alignment.centerLeft,
          margin: const EdgeInsets.only(left: 5.0, top: 10.0, bottom: 40.0),
          child: new Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              //new Expanded(
              new Text('我的预测点位：',
                  style: new TextStyle(
                      fontSize: 14.0,
                      color: Colors.black,
                      fontWeight: FontWeight.normal,
                      decoration: TextDecoration.none)),
              //flex: 1
              //),
              //****** 这里多放一个Expanded是为了让 ‘-’ 这个按钮靠左边

              new Expanded(
                child: new Container(
                  decoration: new BoxDecoration(
                      border:
                          new Border.all(width: 1.0, color: Colors.grey[300])),
                  child: new Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        new Expanded(
                            child: GestureDetector(
                              onLongPress: _longPressMinus,
                              child: new RawMaterialButton(
                                constraints: BoxConstraints(
                                    minHeight: 48.0, minWidth: 48.0),
                                onPressed: _onPressedMinus,
                                child: new Text("-",
                                    style: new TextStyle(
                                        color: Colors.black, fontSize: 40.0)),
                                elevation: 5.0, fillColor: Colors.green[50],
                                //padding: const EdgeInsets.all(0.0),
                              ),
                            ),
                            flex: 2),
                        new Expanded(
                          child: new Padding(
                            padding: new EdgeInsets.all(1.0),
                          ),
                          flex: 1,
                        ),
                        new Expanded(
                          child: new TextField(
                            //decoration: InputDecoration(contentPadding: EdgeInsets.all(2.0)),
                            decoration: null,
                            //cursorRadius: Radius.circular(0.0),
                            //autofocus: true,
                            //cursorWidth: 1.0,
                            controller: _myGuessInputController,
                            keyboardType: TextInputType.number,
                            //inputFormatters: [WhitelistingTextInputFormatter.digitsOnly],
                            //textAlign: TextAlign.left,
                            //autovalidate: true,
                            maxLength: 8,
                            autocorrect: true,

                            onChanged: (String content) {
                              setState(() {
                                myGuess = double.parse(content);
                              });
                            },
                            onSubmitted: (String content) {
                              setState(() {
                                double value = double.parse(content);
                                if (value > (lastSHClose * 1.1) ||
                                    (value < (lastSHClose * 0.9)))
                                  myDialog(context, '涨跌幅不能超过 10 %');
                                else
                                  myGuess = value;
                              });
                            },
                          ),
                          flex: 3,
                        ),
                        new Expanded(
                          child: new Padding(
                            padding: new EdgeInsets.all(1.0),
                          ),
                          flex: 1,
                        ),
                        new GestureDetector(
                          onLongPress: _longPressPlus,
                          child: new RawMaterialButton(
                            constraints:
                                BoxConstraints(minHeight: 48.0, minWidth: 48.0),
                            onPressed: _onPressedPlus,
                            child: new Text("+",
                                style: new TextStyle(
                                    color: Colors.red, fontSize: 40.0)),
                            elevation: 5.0, fillColor: Colors.red[50],
                            //padding: const EdgeInsets.all(0.0),
                          ),
                          //flex: 2,
                        ),
                      ]),
                ),
                flex: 5,
              ),
              new Expanded(
                child: new Padding(
                  padding: new EdgeInsets.all(1.0),
                ),
                flex: 1,
              ),
            ],
          ),
        ),
        new Container(
          margin: const EdgeInsets.only(left: 105.0),
          //width: 50.0, height: 30.0,
          child: new Row(children: <Widget>[
            new RaisedButton(
                color: Colors.blue[400],
                child: new Text('提交预测',
                    style: new TextStyle(fontSize: 12.0, color: Colors.white)),
                onPressed: () {
                  if ((myGuess < lastSHClose * 0.9) ||
                      (myGuess > lastSHClose * 1.1))
                    myDialog(context, '涨跌幅不能超过 10 %');
                  else {
                    showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (BuildContext context) {
                          return new AlertDialog(
                            title: new Text('预测点位：' +
                                myGuess.toStringAsFixed(2) +
                                '\n确定提交？'),
                            actions: <Widget>[
                              new FlatButton(
                                child: new Text('确定'),
                                onPressed: () {
                                  Navigator.of(context).pop(true);
                                  myDialog(context, '已提交，等一段时间可以查看写入区块数据');
                                },
                              ),
                              new FlatButton(
                                child: new Text('否'),
                                onPressed: () {
                                  Navigator.of(context).pop(false);
                                },
                              )
                            ],
                          );
                        });
                  }
                }),
            new Container(
              margin: const EdgeInsets.only(left: 36.0),
              child: new Text(''),
            ),
            new RaisedButton(
              color: Colors.green[400],
              child: new Text('查看结果',
                  style: new TextStyle(fontSize: 12.0, color: Colors.white)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MySubmitResultPage()),
                );
              },
            )
          ]),
        ),
      ]),
    );
  }

  void setupParameter() async {
    configInstance = Config.getInstance;

    double am = await configInstance.engine.getBalance(configInstance.Address);
    setState(() {
      lastSHClose = double.parse(configInstance.DPstr);
      myGuess = lastSHClose;
      step = 0.01;
      amount = am;
      configInstance.amount = am;
       _myGuessInputController.text = myGuess.toStringAsFixed(2);
    });
  }
}
